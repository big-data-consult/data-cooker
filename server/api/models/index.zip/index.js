const path = require('path');
const Sequelize = require("sequelize");
// const sequelize = new Sequelize();
// pass your sequelize config here
const env = process.env.NODE_ENV || 'development';
const config = require(path.join(__dirname, '/../../config/_config.json'))[env];


let sequelize;

if (config.use_env_variable) {
	sequelize = new Sequelize(process.env[config.use_env_variable], config);
} else {
	sequelize = new Sequelize(config.database, config.username, config.password, config);
}


// const Avatar = require("./Avatar");
// const Course = require("./Course");
// // const Job = require("./Job");
// const Note = require("./Note");
// // const Permission = require("./Permission");
// const Role = require("./Role");
// const Source = require("./Source");
// const Target = require("./Target");
// // const Task = require("./Task");
// const User = require("./User");

// const models = {
// 	Avatar: Avatar.init(sequelize, Sequelize),
// 	Course: Course.init(sequelize, Sequelize),
// 	// Job: Job.init(sequelize, Sequelize),
// 	Note: Note.init(sequelize, Sequelize),
// 	// Permission: Permission.init(sequelize, Sequelize),
// 	Role: Role.init(sequelize, Sequelize),
// 	Source: Source.init(sequelize, Sequelize),
// 	Target: Target.init(sequelize, Sequelize),
// 	// Task: Task.init(sequelize, Sequelize),
// 	User: User.init(sequelize, Sequelize)
// };

// Object.values(models)
// 	.filter(model => typeof model.associate === "function")
// 	.forEach(model => model.associate(models));

// const db = {
// 	...models,
// 	sequelize
// };

// module.exports = db;


const models = {
	Avatar: require('./Avatar'),
	Course: require('./Course'),
	Job: require('./Job'),
	Note: require('./Note'),
	Permission: require('./Permission'),
	Role: require('./Role'),
	Source: require('./Source'),
	Target: require('./Target'),
	Task: require('./Task'),
	User: require('./User'),
};

// Object.values(models).forEach(model => model.init());

// Object.values(models)
// 	.filter(model => typeof model.associate === "function")
// 	.forEach(model => {
// 		model.associate(models);
// 		console.log(model.associate);
// 	});

// models.Avatar.hasMany(models.User, { as: 'users', foreignKey: 'avatarId' });
models.Course.belongsTo(models.User, { as: 'user' });
models.Note.belongsTo(models.User, { as: 'user' });
// models.Role.hasMany(models.User, { as: 'users', foreignKey: 'roleId' });
models.Source.belongsTo(models.Target, { as: 'target' });
// models.Target.hasMany(models.Source, { as: 'sources', foreignKey: 'targetId' });
// models.User.hasMany(models.Note, { as: 'notes', foreignKey: 'userId' });
// models.User.hasMany(models.Course, { as: 'courses', foreignKey: 'userId' });
models.User.belongsTo(models.Avatar, { as: 'avatar' });
models.User.belongsTo(models.Role, { as: 'role' });


const db = {
	...models,
	sequelize
};

module.exports = db;
